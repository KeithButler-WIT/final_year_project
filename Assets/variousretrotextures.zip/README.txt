All textures created by me, Samuel "GoldenThumbs" Skiff, and are available to use under CC0.

These textures were created with a variety of techniques and tools by me and are not derived from any existing works.
The tools used:
- Gimp.
- Krita.
- Material Maker.
- Substance Designer.